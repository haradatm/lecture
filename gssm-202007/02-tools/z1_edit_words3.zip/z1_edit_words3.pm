package z1_edit_words3;        # ←この行はファイル名にあわせて変更
use strict;                    # ※ファイルの文字コードはUTF-8にする
use utf8;

#--------------------------#
#   このプラグインの設定   #

sub plugin_config{
	return {
		                                             # メニューに表示される名前
		name     => '表記揺れの吸収',
		menu_cnf => 2,                               # メニューの設定(1)
			# 0: いつでも実行可能
			# 1: プロジェクトが開かれてさえいれば実行可能
			# 2: プロジェクトの前処理が終わっていれば実行可能
		menu_grp => '',                              # メニューの設定(2)
			# メニューをグループ化したい場合にこの設定を行う。
			# 必要ない場合は「'',」または「undef,」としておけば良い。
	};
}

#----------------------------------------#
#   メニュー選択時に実行されるルーチン   #

sub exec{
	my $self = shift;
	my $mw = $::main_gui->{win_obj};

	my $config = {
		'友達' =>
			[
				'友人',
				'旧友',
				'親友',
				'盟友',
				'友',
			],
		'愛に関連する語' => 
			[
				'愛情',
				'愛人',
				'恋愛',
				'愛す',
			],
		'ほげ' => 
			[
				'ふが',
			],
	};

	# 親になる語（置換先の語）が存在するかどうかチェック
	foreach my $i (keys %{$config}){
		# 親を検索
		my $hdl2 = mysql_exec->select("
			SELECT genkei.id, genkei.num
			FROM   genkei
			WHERE  genkei.name = '$i'
			LIMIT 1
		",1)->hundle->fetch;

		print "mother: $i, ";

		if ($hdl2){            # 親あり
			print "ok.";
		} else {               # 親なし
			print "ng, ";
			my $new = '';
			foreach my $h (@{$config->{$i}}){ # 親候補を探す
				my $hdl2 = mysql_exec->select("
					SELECT genkei.id, genkei.num
					FROM   genkei
					WHERE  genkei.name = '$h'
					LIMIT 1
				",1)->hundle->fetch;
				if ($hdl2){
					$new = $h;
					last;
				}
			}
			if (length($new)){                # 親候補あり
				mysql_exec->do("
					UPDATE genkei
					SET   name = '$i'
					WHERE name = '$new'
				",1);
				print "replaced";
			}
		}
		print "\n";
	}

	# MySQLデータベース改変のために必要な情報を収集
	my ($hyoso, $genkei);
	foreach my $i (keys %{$config}){

		# 親になる基本形のIDと出現数
		my $hdl = mysql_exec->select("
			SELECT genkei.id, genkei.num
			FROM   genkei
			WHERE  genkei.name = '$i'
			LIMIT 1
		",1)->hundle->fetch;

		next unless $hdl;

		$genkei->{$i}{id}  = $hdl->[0];
		$genkei->{$i}{num} = $hdl->[1];

		# 子ども達の表層語リスト
		my $sql = "
			SELECT hyoso.id
			FROM   hyoso, genkei
			WHERE
				hyoso.genkei_id = genkei.id
				AND 
		";
		my $sql_w;
		my $n = 0;
		foreach my $h (@{$config->{$i}}){
			$sql_w .= " OR " if $n;
			$sql_w .= "genkei.name = '$h'";
			++$n;
		}
		$sql = $sql .= "( $sql_w )";
		my $hdl = mysql_exec->select($sql,1)->hundle;
		while (my $h = $hdl->fetch){
			push @{$hyoso->{$i}}, $h->[0];
		}

		# 子ども達の出現数
		my $hdl = mysql_exec->select("
			SELECT sum(genkei.num)
			FROM   genkei
			WHERE  $sql_w
		",1)->hundle->fetch;
		if ($hdl){
			$genkei->{$i}{add} = $hdl->[0];
		} else {
			$genkei->{$i}{add} = 0;
		}

	}
	
	#use Data::Dumper;
	#my $dump;
	#$dump .= Dumper($hyoso, $genkei);
	#print Jcode->new($dump)->sjis;
	
	# MySQLデータベースの改変を実行！
	foreach my $i (keys %{$config}){
	
		# 表層語テーブル
		my $sql = '';
		$sql .= "
			UPDATE hyoso
			SET    genkei_id = $genkei->{$i}{id}
			WHERE 
		";
		my $n = 0;
		foreach my $h (@{$hyoso->{$i}}){
			$sql .= " OR " if $n;
			$sql .= "id = $h";
			++$n;
		}
		next unless $n;
		mysql_exec->do($sql,1);

		# 基本形テーブル (1)
		$sql = '';
		$sql .= "DELETE FROM genkei\nWHERE ";
		my $n = 0;
		foreach my $h (@{$config->{$i}}){
			$sql .= " OR " if $n;
			$sql .= "name = '$h'";
			++$n;
		}
		mysql_exec->do($sql,1);

		# 基本形テーブル (2)
		my $new_num = $genkei->{$i}{num} + $genkei->{$i}{add};
		$sql = '';
		$sql .= "
			UPDATE genkei
			SET    num = $new_num
			WHERE  id = $genkei->{$i}{id}
		";
		mysql_exec->do($sql,1);
	}

	$mw->messageBox(
		-message => gui_window->gui_jchar
			(
			   "表記揺れを吸収する処理が完了しました。"
			),
		-icon    => 'info',
		-type    => 'ok',
		-title   => 'KH Coder'
	);
	$::main_gui->inner->refresh;

	return 1;
}

1;
